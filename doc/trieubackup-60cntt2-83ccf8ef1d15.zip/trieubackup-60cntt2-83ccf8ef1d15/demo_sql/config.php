<?php
$hostname="localhost";
$username="root";
$password="trieu1234";//xampp thi de trong pass
$dbname="quanly_ban_sua";
?>
